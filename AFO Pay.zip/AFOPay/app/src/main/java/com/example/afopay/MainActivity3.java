package com.example.afopay;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity3 extends AppCompatActivity {
    private EditText amountInput;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        amountInput = findViewById(R.id.amountInput);
        Button btnAddMoney = findViewById(R.id.btnAddMoney);

        btnAddMoney.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amount = amountInput.getText().toString();
                if (!amount.isEmpty()) {
                    Toast.makeText(MainActivity3.this, "Adding " + amount, Toast.LENGTH_SHORT).show();
                    // Logic to add money can be added here
                } else {
                    Toast.makeText(MainActivity3.this, "Please enter an amount", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
