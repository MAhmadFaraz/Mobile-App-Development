package com.example.afopay;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity5 extends AppCompatActivity {
    private EditText amountInput, noteInput;
    private RadioButton phoneRadio, bankRadio;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main5);

        amountInput = findViewById(R.id.amountInput);
        noteInput = findViewById(R.id.noteInput);
        phoneRadio = findViewById(R.id.radioCard);
        bankRadio = findViewById(R.id.radioBankTransfer);
        Button sendMoneyButton = findViewById(R.id.sendMoneyButton);

        sendMoneyButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String amount = amountInput.getText().toString();
                String note = noteInput.getText().toString();
                String method = phoneRadio.isChecked() ? "Phone Number" : "Bank Transfer";

                if (!amount.isEmpty()) {
                    Toast.makeText(MainActivity5.this, "Sent " + amount + " via " + method, Toast.LENGTH_SHORT).show();
                    // Logic to send money
                } else {
                    Toast.makeText(MainActivity5.this, "Please enter an amount", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
