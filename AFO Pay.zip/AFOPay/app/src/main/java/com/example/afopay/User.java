package com.example.afopay;


public class User {
    public String name, email;

    // Default constructor required for Firebase
    public User() { }

    public User(String name, String email) {
        this.name = name;
        this.email = email;
    }
}
